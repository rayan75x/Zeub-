
console.log("MonComptable AI - Démo statique chargée");
